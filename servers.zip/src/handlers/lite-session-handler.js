const { spawn } = require('child_process');
const logger = require('../utils/logger');
const config = require('../config/config');

class LiteSessionHandler {
  constructor() {
    this.sessions = new Map();
  }

  handle(accept, reject, client) {
    const session = accept();
    const sessionId = this.generateSessionId();
    
    logger.info(`New lite session created: ${sessionId} for user: ${client.username}`);

    session.on('pty', (accept, reject, info) => {
      // In lite mode, we accept PTY requests but don't use node-pty
      logger.info(`PTY request (lite mode): ${JSON.stringify(info)}`);
      
      const ptyInfo = {
        cols: info.cols || 80,
        rows: info.rows || 24,
        term: info.term || 'xterm'
      };

      this.sessions.set(sessionId, {
        ptyInfo,
        session,
        client,
        process: null
      });

      accept && accept();
    });

    session.on('shell', (accept, reject) => {
      this.handleShell(accept, reject, session, client, sessionId);
    });

    session.on('exec', (accept, reject, info) => {
      this.handleExec(accept, reject, info, session, client, sessionId);
    });

    session.on('sftp', (accept, reject) => {
      this.handleSftp(accept, reject, session, client);
    });

    session.on('close', () => {
      this.cleanupSession(sessionId);
    });
  }

  handleShell(accept, reject, session, client, sessionId) {
    logger.info(`Shell request (lite mode) for user: ${client.username}`);
    
    const stream = accept();
    const sessionData = this.sessions.get(sessionId) || { ptyInfo: { cols: 80, rows: 24, term: 'xterm' } };
    
    const userConfig = client.userConfig || {};
    const shell = userConfig.shell || config.terminal.shell;
    const homeDir = userConfig.home || process.env.HOME || '/tmp';

    // Create process without PTY using regular spawn
    const childProcess = spawn(shell, [], {
      cwd: homeDir,
      env: {
        ...process.env,
        ...config.terminal.env,
        USER: client.username,
        HOME: homeDir,
        SHELL: shell,
        TERM: sessionData.ptyInfo.term,
        COLUMNS: sessionData.ptyInfo.cols.toString(),
        LINES: sessionData.ptyInfo.rows.toString()
      },
      stdio: ['pipe', 'pipe', 'pipe']
    });

    // Store process in session
    sessionData.process = childProcess;
    this.sessions.set(sessionId, sessionData);

    // Handle process output
    childProcess.stdout.on('data', (data) => {
      stream.write(data);
    });

    childProcess.stderr.on('data', (data) => {
      stream.stderr.write(data);
    });

    childProcess.on('exit', (code, signal) => {
      logger.info(`Process exited with code: ${code}, signal: ${signal}`);
      stream.end();
    });

    childProcess.on('error', (err) => {
      logger.error(`Process error: ${err.message}`);
      stream.end();
    });

    // Handle stream data
    stream.on('data', (data) => {
      if (childProcess.stdin.writable) {
        childProcess.stdin.write(data);
      }
    });

    // Handle window resize (limited support without PTY)
    stream.on('window-change', (info) => {
      logger.info(`Window resize (lite mode): ${info.cols}x${info.rows}`);
      sessionData.ptyInfo.cols = info.cols;
      sessionData.ptyInfo.rows = info.rows;
      
      // Try to update environment variables for new commands
      if (childProcess.stdin.writable) {
        childProcess.stdin.write(`export COLUMNS=${info.cols} LINES=${info.rows}\n`);
      }
    });

    stream.on('close', () => {
      logger.info(`Stream closed for lite session: ${sessionId}`);
      if (childProcess && !childProcess.killed) {
        childProcess.kill();
      }
      this.cleanupSession(sessionId);
    });

    // Send welcome message
    const welcomeMessage = this.getWelcomeMessage(client.username);
    if (childProcess.stdin.writable) {
      childProcess.stdin.write(`echo "${welcomeMessage}"\n`);
    }
  }

  handleExec(accept, reject, info, session, client, sessionId) {
    logger.info(`Exec request (lite mode): ${info.command}`);
    
    const stream = accept();
    const userConfig = client.userConfig || {};
    const shell = userConfig.shell || config.terminal.shell;
    const homeDir = userConfig.home || process.env.HOME || '/tmp';

    // Execute command without PTY
    const childProcess = spawn(shell, ['-c', info.command], {
      cwd: homeDir,
      env: {
        ...process.env,
        ...config.terminal.env,
        USER: client.username,
        HOME: homeDir,
        SHELL: shell
      },
      stdio: ['pipe', 'pipe', 'pipe']
    });

    childProcess.stdout.on('data', (data) => {
      stream.write(data);
    });

    childProcess.stderr.on('data', (data) => {
      stream.stderr.write(data);
    });

    childProcess.on('exit', (code, signal) => {
      logger.info(`Command exited with code: ${code}, signal: ${signal}`);
      stream.exit(code || 0);
    });

    childProcess.on('error', (err) => {
      logger.error(`Command error: ${err.message}`);
      stream.exit(1);
    });

    stream.on('close', () => {
      if (childProcess && !childProcess.killed) {
        childProcess.kill();
      }
    });
  }

  handleSftp(accept, reject, session, client) {
    logger.info(`SFTP request (lite mode) for user: ${client.username}`);
    // For now, reject SFTP requests - can be implemented later
    reject();
  }

  generateSessionId() {
    return Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
  }

  cleanupSession(sessionId) {
    const sessionData = this.sessions.get(sessionId);
    if (sessionData && sessionData.process && !sessionData.process.killed) {
      sessionData.process.kill();
    }
    this.sessions.delete(sessionId);
    logger.info(`Lite session cleaned up: ${sessionId}`);
  }

  getWelcomeMessage(username) {
    return `Welcome to SSH Server (Lite Mode), ${username}! Limited terminal features available.`;
  }
}

module.exports = LiteSessionHandler;